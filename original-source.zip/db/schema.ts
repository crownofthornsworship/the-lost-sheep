import { integer, sqliteTable, text, index } from "drizzle-orm/sqlite-core";
export const scores = sqliteTable("scores", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  score: integer("score").notNull(),
  levels: integer("levels").notNull(),
  createdAt: integer("created_at").notNull(),
}, (table) => [index("idx_scores_rank").on(table.score, table.levels)]);
