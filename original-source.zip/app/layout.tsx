import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "The Lost Sheep",
  description: "A gentle shepherd adventure with fourteen lands and a shared high score board.",
  metadataBase: new URL("https://the-lost-sheep-game.crownofthornsworship.chatgpt.site/"),
  openGraph: { title: "The Lost Sheep", description: "Gather the flock, watch for the bramble wolf, and explore fourteen lands.", url: "https://the-lost-sheep-game.crownofthornsworship.chatgpt.site/", type: "website", images: [{ url: "/og.png", width: 1200, height: 630, alt: "The Lost Sheep game artwork" }] },
  twitter: { card: "summary_large_image", title: "The Lost Sheep", description: "Gather the flock, watch for the bramble wolf, and explore fourteen lands.", images: ["/og.png"] },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
